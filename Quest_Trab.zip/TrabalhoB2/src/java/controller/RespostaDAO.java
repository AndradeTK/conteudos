/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Banco;
import model.Resposta;

/**
 *
 * @author prampero
 */
public class RespostaDAO {
    
     public int incluir(Resposta obj) throws Exception {
        Banco bb;
        int qtde = 0;
        try {
            bb = new Banco();
            bb.comando = Banco.conexao.prepareStatement("Insert into resposta(cpfuser,r1,r2,r3) " +
" values(?,?,?,?)");
            bb.comando.setString(1, obj.getCpfuser());
            bb.comando.setString(2, String.valueOf(obj.getR1()));
            bb.comando.setString(3, String.valueOf(obj.getR2()));
            bb.comando.setString(4, String.valueOf(obj.getR3()));
            
            qtde = bb.comando.executeUpdate();
            Banco.conexao.close();
            return (qtde);
        } catch (Exception ex) {
            throw new Exception("Erro ao incluir resposta no banco: " + ex.getMessage());
        }
    }
     
    public Resposta preencher(String cpfUser) throws Exception {
        Banco bb;
        Resposta obj=null;
        try {
            bb = new Banco();
            bb.comando = Banco.conexao.prepareStatement("Select codigo,cpfuser,r1,r2,r3 from resposta where cpfuser=?");
            bb.comando.setString(1, cpfUser);
            bb.tabela = bb.comando.executeQuery();
            if(bb.tabela.next()){
                obj= new Resposta();
                obj.setCodigo(bb.tabela.getInt(1));
                obj.setCpfuser(bb.tabela.getString(2));
                obj.setR1(bb.tabela.getString(3).charAt(0));
                obj.setR2(bb.tabela.getString(4).charAt(0));
                obj.setR3(bb.tabela.getString(5).charAt(0));
            }
            Banco.conexao.close();
            return (obj);
        } catch (Exception ex) {
            throw new Exception("Erro ao incluir resposta no banco: " + ex.getMessage());
        }
    } 
}
