/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controller;

import model.Banco;
import model.Usuario;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Ponto;
import model.Resposta;

/**
 *
 * @author prampero
 */
public class UsuarioDAO {

    public int incluir(Usuario obj) throws Exception {
        Banco bb;
        int qtde = 0;
        try {
            bb = new Banco();
            bb.comando = Banco.conexao.prepareStatement("Insert into usuario(cpf,senha,login,nome,cep,rua,bairro,cidade,numero) "
                    + " values(?,?,?,?,?,?,?,?,?)");
            bb.comando.setString(1, obj.getCpf());
            bb.comando.setString(2, obj.getSenha());
            bb.comando.setString(3, obj.getLogin());
            bb.comando.setString(4, obj.getNome());
            bb.comando.setString(5, obj.getCep());
            bb.comando.setString(6, obj.getRua());
            bb.comando.setString(7, obj.getBairro());
            bb.comando.setString(8, obj.getCidade());
            bb.comando.setString(9, obj.getNumero());

            qtde = bb.comando.executeUpdate();
            Banco.conexao.close();
            return (qtde);
        } catch (Exception ex) {
            throw new Exception("Erro ao incluir no banco: " + ex.getMessage());
        }
    }

    public Usuario login(String log, String senha) throws Exception {
        Banco banco;
        Usuario obj = null;
        try {
            banco = new Banco();
            banco.comando = Banco.conexao.prepareStatement("Select cpf,senha,login,nome,cep,rua,bairro,cidade, "
                    + " numero from usuario where login=? and senha=?");
            banco.comando.setString(1, log);
            banco.comando.setString(2, senha);
            banco.tabela = banco.comando.executeQuery();
            if (banco.tabela.next()) {
                obj = new Usuario();
                obj.setCpf(banco.tabela.getString(1));
                //obj.setSenha(banco.tabela.getString(2));
                obj.setLogin(banco.tabela.getString(3));
                obj.setNome(banco.tabela.getString(4));
                obj.setCep(banco.tabela.getString(5));
                obj.setRua(banco.tabela.getString(6));
                obj.setBairro(banco.tabela.getString(7));
                obj.setCidade(banco.tabela.getString(8));
                obj.setNumero(banco.tabela.getString(9));
            }
            Banco.conexao.close();
            return (obj);

        } catch (Exception ex) {
            throw new Exception("Erro no login: " + ex.getMessage());
        }
    }

    public Usuario preencher(String cpf) throws Exception {
        Banco banco;
        Usuario obj = null;
        try {
            banco = new Banco();
            banco.comando = Banco.conexao.prepareStatement("Select cpf,senha,login,nome,cep,rua,bairro,cidade, "
                    + " numero from usuario where cpf=?");
            banco.comando.setString(1, cpf);
            banco.tabela = banco.comando.executeQuery();
            if (banco.tabela.next()) {
                obj = new Usuario();
                obj.setCpf(banco.tabela.getString(1));
                //obj.setSenha(banco.tabela.getString(2));
                obj.setLogin(banco.tabela.getString(3));
                obj.setNome(banco.tabela.getString(4));
                obj.setCep(banco.tabela.getString(5));
                obj.setRua(banco.tabela.getString(6));
                obj.setBairro(banco.tabela.getString(7));
                obj.setCidade(banco.tabela.getString(8));
                obj.setNumero(banco.tabela.getString(9));
            }
            Banco.conexao.close();
            return (obj);

        } catch (Exception ex) {
            throw new Exception("Erro no preencher: " + ex.getMessage());
        }
    }

    public ResultSet listarOutros(String cpf) throws Exception {
        Banco banco;
        try {
            banco = new Banco();
            banco.comando = Banco.conexao.prepareStatement("Select u.cpf,u.nome, r.r1,r.r2,r.r3 from usuario u, resposta r "
                    + "where u.cpf=r.cpfuser and  u.cpf != ?");
            banco.comando.setString(1, cpf);
            banco.tabela = banco.comando.executeQuery();

            Banco.conexao.close();
            return (banco.tabela);
        } catch (Exception ex) {
            throw new Exception("Erro no listarOutros: " + ex.getMessage());
        }
    }

    public ArrayList<Ponto> gerarLista(Usuario u) throws Exception {
        Ponto p;
        Resposta rLogado;
        RespostaDAO rDAO;
        ResultSet tabela;
        ArrayList<Ponto> lista;
        int pontos = 0;
        try {
            rDAO = new RespostaDAO();
            tabela = listarOutros(u.getCpf());
            rLogado = rDAO.preencher(u.getCpf());
            lista = new ArrayList<>();
            while (tabela.next()) {
                p = new Ponto();
                p.cpf = tabela.getString(1);
                p.nome = tabela.getString(2);
                pontos = 0;
                if (rLogado.getR1() == tabela.getString(3).charAt(0)) {
                    pontos++;
                }
                if (rLogado.getR2() == tabela.getString(4).charAt(0)) {
                    pontos++;
                }
                if (rLogado.getR3() == tabela.getString(5).charAt(0)) {
                    pontos++;
                }
                p.valor=pontos;
                lista.add(p);
            }
            return (lista);
        } catch (Exception ex) {
            throw new Exception("Erro ao gerarLista: " + ex.getMessage());
        }
    }

}
