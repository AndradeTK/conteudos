package view;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

import controller.RespostaDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import model.Resposta;
import model.Usuario;

/**
 *
 * @author prampero
 */
@WebServlet(urlPatterns = {"/Teste"})
public class Teste extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Resposta obj;
        RespostaDAO objDAO;
        PrintWriter out = response.getWriter();
        ArrayList<Usuario> lista=null;
        Usuario u=null;
        try {
            lista = new ArrayList<>();
            u=new Usuario();
            u.setNome("Zuleika");
            lista.add(u);
            u=new Usuario();
            u.setNome("Ana");
            lista.add(u);
                        u=new Usuario();
            u.setNome("Barnabe");
            lista.add(u);
            //Collections.sort(lista, Comparator.comparingInt(p -> p.getNome()));
            Collections.sort(lista, Comparator.comparing(p -> p.getNome()));
            
            
            /* TODO output your page here. You may use following sample code. */
            obj = new Resposta();
            obj.setCpfuser("1");
            obj.setR1('a');
            obj.setR2('b');
            obj.setR3('c');
            objDAO = new RespostaDAO();
            //objDAO.incluir(obj);
            obj=objDAO.preencher("1");
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Teste</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Codigo: "+obj.getCodigo()+"</h1>");
            out.println("<h1>CPF: "+obj.getCpfuser()+"</h1>");
            out.println("<h1>Resposta 1: "+obj.getR1()+"</h1>");
            out.println("<h1>Resposta 2: "+obj.getR2()+"</h1>");
            out.println("<h1>Resposta 3: "+obj.getR3()+"</h1>");
            for(int i=0;i<lista.size();i++){
                out.println("<h1>"+lista.get(i).getNome()+"</h1>");
            }
            out.println("</body>");
            out.println("</html>");
        }
        catch(Exception ex){
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Teste</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Erro: " + ex.getMessage() + "</h1>");
            out.println("</body>");
            out.println("</html>");          
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
