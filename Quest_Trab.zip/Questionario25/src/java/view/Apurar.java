/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package view;

import controller.QuestaoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.sql.ResultSet;
import java.text.DecimalFormat;
import java.util.ArrayList;

/**
 *
 * @author prampero
 */
@WebServlet(name = "Apurar", urlPatterns = {"/Apurar"})
public class Apurar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        DecimalFormat df= new DecimalFormat("0.00");
        ResultSet tabela;
        QuestaoDAO dao;
        ArrayList<String> listaErro;
        ArrayList<String> listaAcerto;
        int cont = 0;
        int acertos = 0;
        double nota = 0;
        char resp;
        try {
            listaErro = new ArrayList<>();
            listaAcerto = new ArrayList<>();
            dao = new QuestaoDAO();
            tabela = dao.listar();
            while (tabela.next()) {
                cont++;
                resp = request.getParameter("q" + cont).trim().charAt(0);
                if (resp == tabela.getString("resposta").charAt(0)) {
                    acertos++;
                    listaAcerto.add(tabela.getString("pergunta"));
                } else {
                    listaErro.add(tabela.getString("pergunta"));
                }
            }
            nota = (10.0 * acertos) / cont;
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Apurar</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Sua nota foi: " + df.format(nota) + " </h1>");
            if(nota > 9){
                out.println("<h2>Parabéns, orgulho do Papai e da Mamãe</h2>");
            }
            if(nota < 2){
                out.println("<h2>Seu Papai e sua Mamãe trabalhando de sol a sol, vai ser mais um nen nen na vida? A colheita é obrigatória, a sua vida pode piorar.</h2>");
            }
            
            if (listaAcerto.size() > 0) {
                out.println("<h1>Acertou</h1>");
                for (String s : listaAcerto) {
                    out.println("<h2>" + s + "</h2>");
                }
            }
            if (listaErro.size() > 0) {
                out.println("<h1>Errou</h1>");
                for (String s : listaErro) {
                    out.println("<h2>" + s + "</h2>");
                }
            }
            
            out.println("</body>");
            out.println("</html>");
        } catch (Exception ex) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Apurar - Erro</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Erro:  " + ex.getMessage() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
