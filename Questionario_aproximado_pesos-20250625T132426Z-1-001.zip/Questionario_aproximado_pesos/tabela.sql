drop table if exists questao;
create table questao(
codigo serial primary key,
pergunta varchar(200) NOT NULL,
a varchar(100),
b varchar(100),
c varchar(100),
d varchar(100),
resposta char NOT NULL
);

insert into questao (pergunta, a, b, c, d, resposta) values ('Quanto é 2+2?','-6','4','8','22', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Como simplificar log(x^2)?','2*log(x)', 'log(2) * x', 'log(2x)', 'log(x) + 2', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quem descobriu o cálculo?', 'Laplace', 'Fourier', 'Einstein', 'Newton', 'd');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a derivada de x^3?', 'x^2', '2*x^4', '3*x^2', '2*x^3', 'c');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a integral de 1/x?', '2/x^2', 'log(x)', 'x^log(2)', 'ln(x)', 'd');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual o limite de sen(x)/x quando x se aproxima de 0?', '1', '0', 'pi', 'indefinido', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a derivada de ln(x^2 + 1)?', 'x/(x^2 + 1)', '2x/(x^2 + 1)', '1/(x^2 + 1)', 'ln(2x)', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se f(x) = e^(2x), qual é f''(x)?', '4e^(2x)', '2e^x', 'e^(4x)', '4e^(x)', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Resolva a integral ∫x*e^x dx', 'x^2 * e^x', 'x*e^x - e^x + C', 'e^x + C', 'x*e^x - ∫e^x dx', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a série de Taylor de e^x centrada em 0?', '∑(n^x)/n!', 'x^2 + 1', '1 + x + x^2', '∑(x^n)/n!', 'd');

select * from questao;