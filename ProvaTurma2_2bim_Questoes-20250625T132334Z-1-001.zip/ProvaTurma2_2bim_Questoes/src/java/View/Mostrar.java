package View;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet_pramps.java to edit this template
 */


import Model.Questao;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;

/**
 *
 * @author Aluno
 */
@WebServlet(urlPatterns={"/Mostrar"})
public class Mostrar extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        Questao obj;
        ArrayList<Questao> questoes = new ArrayList<>();
        
        try {
            // Popular vetor de perguntas
            obj = new Questao("Quanto é 2+2?", "-6", "8", "22", "4");
            questoes.add(obj);

            obj = new Questao("Como simplificar log(x^2)?", "log(x) + 2", "log(2) * x", "log(2x)", "2*log(x)");
            questoes.add(obj);

            obj = new Questao("Quem descobriu o cálculo?", "Laplace", "Fourier", "Einstein", "Newton");
            questoes.add(obj);

            obj = new Questao("Qual a derivada de x^3?", "x^2", "2*x^4", "2*x^3", "3*x^2");
            questoes.add(obj);

            obj = new Questao("Qual a integral de 1/x?", "2/x^2", "log(x)", "x^log(2)", "ln(x)");
            questoes.add(obj);

            obj = new Questao("Qual o limite de sen(x)/x quando x se aproxima de 0?", "indefinido", "0", "pi", "1");
            questoes.add(obj);

            obj = new Questao("Qual a derivada de ln(x^2 + 1)?", "1/(x^2 + 1)", "2x/(x^2 + 1)", "ln(2x)", "x/(x^2 + 1)");
            questoes.add(obj);

            obj = new Questao("Se f(x) = e^(2x), qual é f''(x)?", "4e^(2x)", "2e^x", "e^(4x)", "4e^(2x)"); // derivada de exponencial
            questoes.add(obj);

            obj = new Questao("Resolva a integral ∫x*e^x dx", "x^2 * e^x", "e^x + C", "x*e^x - ∫e^x dx", "x*e^x - e^x + C"); // integração por partes
            questoes.add(obj);

            obj = new Questao("Qual a série de Taylor de e^x centrada em 0?", "x^2 + 1", "∑(x^n)/n!", "1 + x + x^2", "∑(x^n)/n!"); // série de Taylor
            questoes.add(obj);
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Mostrar</title>");  
            out.println("</head>");
            out.println("<body>");
            
            out.println("<form action='Avaliar' method='post'>");
            
            for (int i = 0; i < questoes.size(); i++){
                Questao q = questoes.get(i);
                
                out.println((i+1) + ". "+ q.getPergunta() + "<br>");
                
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='a' required>" + q.getA());
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='b'>" + q.getB());
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='c'>" + q.getC());
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='d'>" + q.getD() + "<br><br>");
            }
            
            out.println("<input type='submit' value='Verificar respostas'>");
            
            out.println("</form>");
            
            out.println("</body>");
            out.println("</html>");
        } catch (Exception ex){
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Erro no Mostrar</title>");  
            out.println("</head>");
            out.println("<body>");
            ex.printStackTrace(out);
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
