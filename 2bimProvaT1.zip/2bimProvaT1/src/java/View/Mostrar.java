package View;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet_pramps.java to edit this template
 */


import Model.Questao;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.util.ArrayList;

/**
 *
 * @author Aluno
 */
@WebServlet(urlPatterns={"/Mostrar"})
public class Mostrar extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        
        Questao obj;
        ArrayList<Questao> questoes = new ArrayList<>();
        HttpSession sessao = request.getSession(true);
        
        try {
            // Popular vetor de perguntas
            obj = new Questao("O que você gosta de comer?", "Alface", "Churrasco", "Macarrão", "Melão", 'b');
            questoes.add(obj);

            obj = new Questao("Qual sua cor preferida?", "Rosa", "Azul", "Amarelo", "Vermelho", 'c');
            questoes.add(obj);

            obj = new Questao("Qual seu local preferido?", "Casa", "Escola", "Shopping", "Rua", 'b' );
            questoes.add(obj);
            
            if (sessao.getAttribute("lista") == null){
                sessao.setAttribute("lista", questoes);
            }
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Mostrar</title>");  
            out.println("</head>");
            out.println("<body>");
            
            out.println("<a href=\"paises.html\">Parte dos países</a>");
            
            out.println("<form action='Avaliar' method='post'>");
            
            for (int i = 0; i < questoes.size(); i++){
                Questao q = questoes.get(i);
                
                out.println((i+1) + ". "+ q.getPergunta() + "<br>");
                
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='a' required>" + q.getA());
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='b'>" + q.getB());
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='c'>" + q.getC());
                out.println("<input type='radio' name='resposta"+ (i+1) +"' value='d'>" + q.getD() + "<br><br>");
            }
            
            out.println("<input type='submit' value='Verificar respostas'>");
            
            out.println("</form>");
            
            out.println("</body>");
            out.println("</html>");
        } catch (Exception ex){
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Erro no Mostrar</title>");  
            out.println("</head>");
            out.println("<body>");
            ex.printStackTrace(out);
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}