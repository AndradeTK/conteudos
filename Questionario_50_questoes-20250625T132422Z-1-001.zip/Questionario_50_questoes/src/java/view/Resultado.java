/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */

package view;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.text.DecimalFormat;
import java.util.ArrayList;
import model.Questao;

/**
 *
 * @author mathe
 */
@WebServlet(name="Resultado", urlPatterns={"/Resultado"})
public class Resultado extends HttpServlet {
   
    /** 
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code> methods.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        HttpSession sessao = request.getSession(true);
        ArrayList<String> respostas = (ArrayList<String>) sessao.getAttribute("listaRespostas");
        ArrayList<Questao> questoes = (ArrayList<Questao>) sessao.getAttribute("listaQuestoes");
        
        ArrayList<Questao> listaErro;
        ArrayList<Questao> listaAcerto;
        ArrayList<Questao> listaAcertoParcial;
        
        DecimalFormat df= new DecimalFormat("0.00");
        
        boolean todasRespondidas = true;
        
        double denominador = 0;
        double acertos = 0;
        double nota = 0;
        
        try {
            
            listaErro = new ArrayList<>();
            listaAcerto = new ArrayList<>();
            listaAcertoParcial = new ArrayList<>();
            
            for (int i = 0; i < respostas.size(); i++){
                Questao q = questoes.get(i);
                String r = respostas.get(i);
                if (r.equals("")){
                    todasRespondidas = false;
                    break;
                }
                char resp = r.charAt(0);
                char respostaCerta = q.getResposta();
                
                denominador += i+1;
                
                if (resp == respostaCerta){
                    acertos += (i+1);
                    listaAcerto.add(q);
                } else if (Math.abs(resp - respostaCerta) == 1){
                    acertos += (i+1)/2.0;
                    listaAcertoParcial.add(q);
                }else {
                    listaErro.add(q);
                }
                
            }
            
            nota = 10 * acertos/denominador;
            
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Resultado</title>");  
            out.println("</head>");
            out.println("<body>");
            if (todasRespondidas){
                out.println("<h1>Sua nota foi: " + df.format(nota) + " </h1>");
                
                if(nota > 9){
                    out.println("<h2>Parabéns, orgulho do Papai e da Mamãe</h2>");
                }
                if(nota < 2){
                    out.println("<h2>Seu Papai e sua Mamãe trabalhando de sol a sol, vai ser mais um nen nen na vida? A colheita é obrigatória, a sua vida pode piorar.</h2>");
                }
                
                if (listaAcerto.size() > 0) {
                    out.println("<h1>Acertou</h1>");
                    for (Questao q : listaAcerto) {
                        out.println("<h2>" + q.getPergunta() + "</h2>");
                    }
                }

                if (listaAcertoParcial.size() > 0) {
                    out.println("<h1>Acertou parcialmente</h1>");
                    for (Questao q : listaAcertoParcial) {
                        out.println("<h2>" + q.getPergunta() + "</h2>");
                    }
                }

                if (listaErro.size() > 0) {
                    out.println("<h1>Errou</h1>");
                    for (Questao q : listaErro) {
                        out.println("<h2>" + q.getPergunta() + "</h2>");
                    }
                }
                
                sessao.invalidate();
            }else{
                out.println("<h1>Ainda não respondeu todas as questões.</h1>");
            }
            
            out.println("</body>");
            out.println("</html>");
        } catch (Exception ex){
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Erro no Resultado</title>");  
            out.println("</head>");
            out.println("<body>");
            ex.printStackTrace(out);
            out.println("</body>");
            out.println("</html>");
        }
    } 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /** 
     * Handles the HTTP <code>GET</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    } 

    /** 
     * Handles the HTTP <code>POST</code> method.
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    /** 
     * Returns a short description of the servlet.
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}