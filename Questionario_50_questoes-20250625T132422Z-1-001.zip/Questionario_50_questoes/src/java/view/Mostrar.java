/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package view;

import controller.QuestaoDAO;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Questao;


/**
 *
 * @author prampero
 */
@WebServlet(name = "Mostrar", urlPatterns = {"/Mostrar"})
public class Mostrar extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        ResultSet tabela;
        
        QuestaoDAO dao;
        ArrayList<Questao> questoes;
        
        String resp;
        int posicao;
        
        HttpSession sessao = request.getSession(true);
        try {
            questoes = (ArrayList<Questao>) sessao.getAttribute("listaQuestoes");
            if (questoes == null){
                dao = new QuestaoDAO();
                tabela = dao.randomizar10();
                questoes = new ArrayList<>();
                
                while (tabela.next()){ // Popular vetor de questões
                    Questao q = new Questao();
                    q.setPergunta(tabela.getString("pergunta"));
                    q.setA(tabela.getString("a"));
                    q.setB(tabela.getString("b"));
                    q.setC(tabela.getString("c"));
                    q.setD(tabela.getString("d"));
                    q.setResposta(tabela.getString("resposta").charAt(0));
                    
                    questoes.add(q);
                }
                
                sessao.setAttribute("listaQuestoes", questoes);
            }
            
            if (sessao.getAttribute("pos") == null){
                posicao = 0;
                sessao.setAttribute("pos", posicao);
            }else{
                posicao = (int) sessao.getAttribute("pos");
            }
            
            if (sessao.getAttribute("listaRespostas") != null){
                resp = ((ArrayList<String>) sessao.getAttribute("listaRespostas")).get(posicao);
            }else{
                resp = "";
            }
            
            
            Questao questaoAtual = questoes.get(posicao);
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Mostrar</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1> Exame final do Prampero </h1>");
            out.println("<h1>"+questoes.size()+" perguntas na base. </h1>");
            
            out.println("<form action='Apurar' method='post'>");
            
            out.println("<h2>"+(posicao+1)+") " + questaoAtual.getPergunta() + "</h2>");
            out.println("<font size='5px'><input type='radio' name='q' value='a' " + ("a".equals(resp) ? "checked" : "") + " />a) " + questaoAtual.getA() + "</font> ");
            out.println("<font size='5px'><input type='radio' name='q' value='b' " + ("b".equals(resp) ? "checked" : "") + " />b) " + questaoAtual.getB() + "</font> ");
            out.println("<font size='5px'><input type='radio' name='q' value='c' " + ("c".equals(resp) ? "checked" : "") + " />c) " + questaoAtual.getC() + "</font> ");
            out.println("<font size='5px'><input type='radio' name='q' value='d' " + ("d".equals(resp) ? "checked" : "") + " />d) " + questaoAtual.getD() + "</font><br/>");


            out.println("<br/>");
            
            if (posicao > 0) out.println("<input type='submit' name='b1' value='Anterior' />");
            if (posicao < 9) out.println("<input type='submit' name='b1' value='Próxima' />");
            else out.println("<input type='submit' name='b1' value='Enviar' />");
            
            
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        } catch (Exception ex) {
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Mostrar</title>");
            out.println("</head>");
            out.println("<body>");
            out.println("<h1>Erro: " + ex.getMessage() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
