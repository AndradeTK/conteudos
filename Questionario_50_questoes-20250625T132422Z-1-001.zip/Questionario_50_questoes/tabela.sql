drop table if exists questao;
create table questao(
codigo serial primary key,
pergunta varchar(200) NOT NULL,
a varchar(100),
b varchar(100),
c varchar(100),
d varchar(100),
resposta char NOT NULL
);

insert into questao (pergunta, a, b, c, d, resposta) values ('Quanto é 2+2?','-6','4','8','22', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Como simplificar log(x^2)?','2*log(x)', 'log(2) * x', 'log(2x)', 'log(x) + 2', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quem descobriu o cálculo?', 'Laplace', 'Fourier', 'Einstein', 'Newton', 'd');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a derivada de x^3?', 'x^2', '2*x^4', '3*x^2', '2*x^3', 'c');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a integral de 1/x?', '2/x^2', 'log(x)', 'x^log(2)', 'ln(x)', 'd');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual o limite de sen(x)/x quando x se aproxima de 0?', '1', '0', 'pi', 'indefinido', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a derivada de ln(x^2 + 1)?', 'x/(x^2 + 1)', '2x/(x^2 + 1)', '1/(x^2 + 1)', 'ln(2x)', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se f(x) = e^(2x), qual é f''(x)?', '4e^(2x)', '2e^x', 'e^(4x)', '4e^(x)', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Resolva a integral ∫x*e^x dx', 'x^2 * e^x', 'x*e^x - e^x + C', 'e^x + C', 'x*e^x - ∫e^x dx', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a série de Taylor de e^x centrada em 0?', '∑(n^x)/n!', 'x^2 + 1', '1 + x + x^2', '∑(x^n)/n!', 'd');

insert into questao (pergunta, a, b, c, d, resposta) values ('Quanto é 7 * 6?', '42', '36', '40', '48', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a raiz quadrada de 144?', '11', '12', '13', '14', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantos graus tem um ângulo reto?', '45', '90', '180', '360', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é o valor de π (pi) aproximado?', '3.14', '2.71', '1.62', '1.41', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quem é conhecido como o pai da álgebra?', 'Gauss', 'Newton', 'Al-Khwarizmi', 'Euler', 'c');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quanto é 2^5?', '10', '25', '32', '16', 'c');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a derivada de sen(x)?', 'cos(x)', '-sen(x)', '-cos(x)', 'sec^2(x)', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é o determinante da matriz [[1,2],[3,4]]?', '-2', '10', '2', '0', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se f(x) = x^2, qual é f(3)?', '6', '9', '3', '12', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual o próximo número da sequência: 2, 4, 8, 16, ...?', '18', '20', '24', '32', 'd');

insert into questao (pergunta, a, b, c, d, resposta) values ('Quanto é (3 + 2) * 4?', '20', '14', '24', '16', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se log(1000) = x, qual é o valor de x na base 10?', '1', '2', '3', '0', 'c');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a derivada de cos(x)?', 'sen(x)', '-sen(x)', '-cos(x)', 'tan(x)', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a fórmula da área de um triângulo?', 'b*h', '(b*h)/2', 'π*r^2', '2*b + 2*h', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se a média de 3, 5 e x é 7, quanto vale x?', '13', '11', '12', '9', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é o número de Euler?', '1.41', '2.71', '3.14', '0.57', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é o resultado da integral ∫cos(x)dx?', 'sen(x) + C', '-cos(x) + C', 'cos(x) + C', '-sen(x) + C', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual o valor de lim(x→0) (1 - cos(x))/x^2?', '0', '1/2', '1', '∞', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é o grau do polinômio f(x) = 4x^5 - x^2 + 3?', '2', '5', '3', '4', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantos lados tem um dodecágono?', '10', '12', '8', '14', 'b');

insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a função inversa de f(x) = 2x + 3?', 'f⁻¹(x) = (x-3)/2', 'f⁻¹(x) = x/2 + 3', 'f⁻¹(x) = 2x - 3', 'f⁻¹(x) = x/2 - 3', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantas soluções reais tem a equação x^2 + 4 = 0?', '0', '1', '2', 'infinitas', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se P(A) = 0.4 e P(B) = 0.5, qual o máximo valor de P(A ∩ B)?', '0.4', '0.5', '0.9', '0.0', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantos segundos há em uma hora?', '3600', '600', '60', '1800', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a equação da parábola que tem vértice na origem e se abre para cima?', 'y = x', 'y = x^2', 'y = 2x + 1', 'x = y^2', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Resolva: ∫ln(x) dx', 'xln(x) - x + C', 'ln(x^2) + C', '1/x + C', 'xln(x) + x + C', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é o valor de e^(ln(5))?', '5', '1', '0', 'ln(5)', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a probabilidade de sair cara em uma moeda justa?', '1', '0', '0.25', '0.5', 'd');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantas diagonais tem um hexágono?', '9', '12', '15', '18', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('A soma dos ângulos internos de um pentágono é?', '540°', '360°', '180°', '720°', 'a');

insert into questao (pergunta, a, b, c, d, resposta) values ('Quanto é o fatorial de 5?', '20', '60', '120', '24', 'c');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se x + y = 10 e x - y = 4, quanto vale x?', '2', '7', '5', '6', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('O que representa a derivada de uma função em um ponto?', 'Área', 'Inclinação da reta tangente', 'Volume', 'Comprimento do arco', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantos elementos tem o conjunto das letras da palavra "matemática"?', '8', '9', '7', '6', 'd');
insert into questao (pergunta, a, b, c, d, resposta) values ('Se f(x) = ln(x), qual é f''(x)?', '1/x', 'x', 'ln(x)^2', 'e^x', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a equação da circunferência com centro na origem e raio 3?', 'x^2 + y^2 = 9', 'x + y = 3', 'x^2 - y^2 = 9', 'x^2 + y^2 = 6', 'a');
insert into questao (pergunta, a, b, c, d, resposta) values ('Quantos números primos existem entre 1 e 20?', '7', '8', '9', '6', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual é a mediana do conjunto: 3, 7, 9, 11, 15?', '7', '9', '11', '8', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('Qual a integral definida de x de 0 a 1?', '1', '1/2', '0', '1/4', 'b');
insert into questao (pergunta, a, b, c, d, resposta) values ('O gráfico de y = |x| é?', 'Uma parábola', 'Uma reta inclinada', 'Um "V"', 'Um "U"', 'c');

select * from questao;