function googlemaps() {
    const nomePais = document.getElementById('idNome').value;
    fetch(`https://restcountries.com/v3.1/name/${nomePais}`, {
        method: 'GET',
        headers: {
            "Content-Type": "application/json",
        },
    })
        .then(response => response.json())
        .then(data => {
            if (Array.isArray(data) && data.length > 0 && data[0].maps && data[0].maps.googleMaps) {
                document.getElementById("idLink").innerHTML =
                    `<a href="${data[0].maps.googleMaps}" target="_blank">Ver no Google Maps</a>`;
                document.getElementById("erro").innerHTML = "";
            } else {
                document.getElementById("erro").innerHTML = "País não encontrado";
                document.getElementById("idLink").innerHTML = "";
            }
        })
        .catch(erro => {
            document.getElementById("erro").innerHTML = "Erro ao listar: " + erro;
            document.getElementById("idLink").innerHTML = "";
        });
}