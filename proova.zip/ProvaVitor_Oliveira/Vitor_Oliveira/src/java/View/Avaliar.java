/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package View;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 *
 * @author vtr17
 */

@WebServlet(urlPatterns={"/Avaliar"})
public class Avaliar extends HttpServlet {

    // Respostas corretas: 1 b, 2 c, 3 b
    private final char[] respostasCertas = {'b', 'c', 'b'};

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();
        int pontos = 0;

        try {
            for (int i = 0; i < respostasCertas.length; i++) {
                String r = request.getParameter("resposta" + (i+1));
                if (r == null) continue;
                char resposta = r.charAt(0);
                char certa = respostasCertas[i];

                if (resposta == certa) {
                    pontos += 2;
                } else if (isAdjacente(resposta, certa)) {
                    pontos += 1;
                }
            }

            out.println("<!DOCTYPE html><html><head><title>Resultado</title></head><body>");
            out.println("<h2>Você fez " + pontos + " ponto(s)!</h2>");
            out.println("<a href='Mostrar'>Tentar novamente</a>");
            out.println("</body></html>");
        } finally {
            out.close();
        }
    }

    // Confere se a alternativa está ao lado da correta (ex: b e c são vizinhas)
    private boolean isAdjacente(char resposta, char certa) {
        return Math.abs(resposta - certa) == 1;
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
}