/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package View;

import Model.Questao;
import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.util.ArrayList;

/**
 *
 * @author vtr17
 */

@WebServlet(urlPatterns={"/Mostrar"})
public class Mostrar extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");
        PrintWriter out = response.getWriter();

        ArrayList<Questao> questoes = new ArrayList<>();
        try {
            // Exemplo para 3 perguntas, para 1000 basta usar um loop (vide comentário abaixo)
            questoes.add(new Questao("O que você gosta de comer?", "Alface", "Churrasco", "Macarrão", "Melão"));
            questoes.add(new Questao("Qual sua cor preferida?", "Rosa", "Azul", "Amarelo", "Vermelho"));
            questoes.add(new Questao("Qual seu local preferido?", "Casa", "Escola", "Shopping", "Rua"));

            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Mostrar</title>");
            out.println("<script src='script.js'></script>");
            out.println("</head>");
            out.println("<body>");
            out.println("Nome do País em inglês: <input type='text' id='idNome'><br>");
            out.println("<input type='button' value='Mostrar' onclick='googlemaps()'><br>");
            out.println("<div id='idLink'></div>");
            out.println("<div id='erro' style='color:red'></div>");
            out.println("<form action='Avaliar' method='post'>");

            for (int i = 0; i < questoes.size(); i++) {
                Questao q = questoes.get(i);
                out.println((i+1) + ". " + q.getPergunta() + "<br>");
                out.println("<input type='radio' name='resposta"+(i+1)+"' value='a' required>" + q.getA());
                out.println("<input type='radio' name='resposta"+(i+1)+"' value='b'>" + q.getB());
                out.println("<input type='radio' name='resposta"+(i+1)+"' value='c'>" + q.getC());
                out.println("<input type='radio' name='resposta"+(i+1)+"' value='d'>" + q.getD() + "<br><br>");
            }

            out.println("<input type='submit' value='Verificar respostas'>");
            out.println("</form>");
            out.println("</body>");
            out.println("</html>");
        } finally {
            out.close();
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
        processRequest(request, response);
    }
}